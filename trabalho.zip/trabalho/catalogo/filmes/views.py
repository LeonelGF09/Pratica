from django.shortcuts import render
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status

from .models import Filme
from .serializers import FilmeSerializer


@api_view(['GET', 'POST'])
def filmes_lista(request):

    if request.method == 'GET':
        nome = request.GET.get('nome')

        if nome:
            filmes = Filme.objects.filter(nome__icontains=nome)
        else:
            filmes = Filme.objects.all()

        serializer = FilmeSerializer(filmes, many=True)

        return Response(serializer.data)

    if request.method == 'POST':
        serializer = FilmeSerializer(data=request.data)

        if serializer.is_valid():
            serializer.save()
            return Response(
                serializer.data,
                status=status.HTTP_201_CREATED
            )

        return Response(
            serializer.errors,
            status=status.HTTP_400_BAD_REQUEST
        )


@api_view(['GET', 'DELETE'])
def filme_detalhe(request, id):

    try:
        filme = Filme.objects.get(id=id)
    except Filme.DoesNotExist:
        return Response(
            {'erro': 'Filme não encontrado.'},
            status=status.HTTP_404_NOT_FOUND
        )

    if request.method == 'GET':
        serializer = FilmeSerializer(filme)
        return Response(serializer.data)

    if request.method == 'DELETE':
        filme.delete()

        return Response(
            status=status.HTTP_204_NO_CONTENT
        )
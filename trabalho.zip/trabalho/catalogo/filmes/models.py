from django.db import models

class Filme(models.Model):
    nome = models.CharField(max_length=200)
    
    class Generos(models.TextChoices):
        ACAO = 'ação', 'Ação'
        COMEDIA = 'comédia', 'Comédia'
        DRAMA = 'drama', 'Drama'
        TERROR = 'terror', 'Terror'
        ROMANCE = 'romance', 'Romance'
        FICCAO_CIENTIFICA = 'ficção científica', 'Ficção Científica'
        SUSPENSE = 'suspense', 'Suspense'
        ANIMACAO = 'animação', 'Animação'
    
    genero = models.CharField(
        max_length=50,
        choices=Generos.choices,
        default=Generos.ACAO
    )

    duracao = models.DurationField()
    elenco = models.CharField(max_length=500)
    assistido = models.BooleanField(default=False)

    def __str__(self):
        return self.nome



from django.urls import path
from . import views


urlpatterns = [
    path('filmes/', views.filmes_lista),
    path('filmes/<int:id>/', views.filme_detalhe),
]
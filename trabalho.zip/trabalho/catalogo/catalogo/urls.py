from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('filmes/', include('filmes.urls')),
    path('api/', include('filmes.urls')),
]




